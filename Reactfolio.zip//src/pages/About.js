import profilePic from "../assets/profile.jpg";
import "./About.css";
import { useEffect, useState } from "react";

const About = () => {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    setAnimate(true);
  }, []);

  return (
    <div className="about">
      <h2>About Me</h2>
      <img src={profilePic} alt="Vikas Singh" className="profile-image" />
      <br />
      <p>
        I am Vikas Singh, a Frontend Developer! I specialize in building modern,
        responsive web applications with React, JavaScript, and CSS.
      </p>

      {/* Skills Section */}
      <div className="skills">
        <br />
        <h3>My Skills</h3>
        <br />

        {[
          { name: "HTML", level: "90%" },
          { name: "CSS", level: "85%" },
          { name: "JavaScript", level: "80%" },
          { name: "React", level: "75%" },
          { name: "Firebase", level: "70%" },
          { name: "Figma", level: "65%" },
        ].map((skill, index) => (
          <div className={`skill ${skill.name.toLowerCase()}`} key={index}>
            <div className="skill-label">{skill.name}</div>
            <div className="progress-bar">
              <div
                className={`progress ${animate ? "animate" : ""}`}
                style={{ width: skill.level }}
              ></div>
              <div className="progress-label">{skill.level}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default About;
