import "./Home.css"; // Import CSS
import profilePic from "../assets/profile.jpg"; // Import profile image

const Home = () => {
  return (
    <div className="home">
      <h2>Welcome to My Portfolio</h2>

      <p>
        Hi, I'm Vikas Singh, a passionate frontend developer from Faridabad.
        With a keen interest in crafting seamless user experiences, I thrive on
        solving complex problems. When not coding, you can find me kicking a
        football or pounding the pavement, as I'm an avid runner and football
        enthusiast.
      </p>
    </div>
  );
};

export default Home;
