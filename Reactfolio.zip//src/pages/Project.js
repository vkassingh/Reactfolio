import "./Project.css";
import portfolioImg from "../assets/portfolio.jpg";
import ecommerceImg from "../assets/ecommerce.jpg";
import taskManagerImg from "../assets/task-manager.jpg";

const projects = [
  {
    id: 1,
    title: "Portfolio Website",
    description: "A personal portfolio built with React and styled components.",
    image: portfolioImg, // ✅ Use the imported image
    url: "https://vikas-portfolio.com",
  },
  {
    id: 2,
    title: "E-Commerce App",
    description:
      "An online shopping platform using React, Firebase, and Stripe.",
    image: ecommerceImg,
    url: "https://ecommerce-demo.com",
  },
  {
    id: 3,
    title: "Task Manager",
    description:
      "A simple task management app built with React and local storage.",
    image: taskManagerImg,
    url: "https://taskmanager.com",
  },
];

const Project = () => {
  return (
    <div className="project-container">
      <h2>My Projects</h2>
      <p>These are dummy projects for demonstration purposes.</p>
      <div className="project-grid">
        {projects.map((project) => (
          <div key={project.id} className="project-card">
            <img
              src={project.image}
              alt={project.title}
              className="project-image"
            />
            <h3>{project.title}</h3>
            <p>{project.description}</p>
            <a href={project.url} target="_blank" rel="noopener noreferrer">
              View Project
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Project;
